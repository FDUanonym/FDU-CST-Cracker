import torch
import torch.nn as nn


class Mask(nn.Module):
    def __init__(self, n_voc, p_mask, p_keep, p_random):
        super(Mask, self).__init__()
        self.n_voc = n_voc              # [mask] token too
        self.p_mask = p_mask            # probability of masking with [mask] token
        self.p_keep = p_keep            # probability of keeping the same token
        self.p_random = p_random        # probability of replacing with a random token

    def __call__(self, x):
        mask_mask = torch.rand(x.shape, device=x.device) < self.p_mask
        mask_keep = mask_mask & (torch.rand(x.shape, device=x.device) < self.p_keep)
        mask_random = mask_mask & (torch.rand(x.shape, device=x.device) < self.p_random)
        index_random = torch.nonzero(mask_random, as_tuple=True)    # coordinates of tokens to be replaced randomly
        token_random = torch.randint(0, self.n_voc, (len(index_random[0]),), device=x.device)   # new replacing tokens
        mask_mask = mask_mask & ~mask_keep & ~mask_random

        x.masked_fill_(mask_mask, self.n_voc)
        x[index_random] = token_random
        return x
