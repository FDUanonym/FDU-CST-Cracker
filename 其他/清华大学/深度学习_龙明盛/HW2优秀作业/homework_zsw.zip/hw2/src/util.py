import os
from genericpath import exists
import matplotlib.pyplot as plt


def plot(train_loss, valid_loss, plot_dir, title):  # plot loss curves
    if not exists(plot_dir):
        os.makedirs(plot_dir)
    x = [i for i in range(len(train_loss))]
    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    ax1.plot(x, train_loss, 'r', label="train loss")
    ax1.legend(loc=1)
    ax1.set_ylabel('train loss values')
    ax1.set_xlabel('epochs')
    ax2 = ax1.twinx()  # this is the important function
    ax2.plot(x, valid_loss, 'g', label="valid loss")
    ax2.legend(loc=2)
    ax2.set_ylabel('valid loss values')
    plt.title(title)
    plt.savefig(os.path.join(plot_dir, title) + '.png')
    plt.close(fig)
