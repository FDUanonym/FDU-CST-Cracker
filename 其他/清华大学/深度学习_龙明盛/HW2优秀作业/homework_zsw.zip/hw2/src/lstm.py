import math
import torch
import torch.nn as nn


class LSTMCell(nn.Module):
    def __init__(self, n_input, n_hid):
        super().__init__()
        self.W_ix = nn.Parameter(torch.Tensor(n_input, n_hid))
        self.W_fx = nn.Parameter(torch.Tensor(n_input, n_hid))
        self.W_ox = nn.Parameter(torch.Tensor(n_input, n_hid))
        self.W_gx = nn.Parameter(torch.Tensor(n_input, n_hid))
        self.W_ih = nn.Parameter(torch.Tensor(n_hid, n_hid))
        self.W_fh = nn.Parameter(torch.Tensor(n_hid, n_hid))
        self.W_oh = nn.Parameter(torch.Tensor(n_hid, n_hid))
        self.W_gh = nn.Parameter(torch.Tensor(n_hid, n_hid))
        self.b_i = nn.Parameter(torch.Tensor(1, n_hid))
        self.b_f = nn.Parameter(torch.Tensor(1, n_hid))
        self.b_g = nn.Parameter(torch.Tensor(1, n_hid))
        self.b_o = nn.Parameter(torch.Tensor(1, n_hid))
        self.n_hid = n_hid
        self.init_weights()

    def init_weights(self):
        stdv = 1.0 / math.sqrt(self.n_hid)
        for param in self.parameters():
            nn.init.uniform_(param, -stdv, stdv)

    def forward(self, x: torch.Tensor, h, c):
        # x: current input
        # h: last hidden
        # c: last state
        i = x @ self.W_ix + h @ self.W_ih + self.b_i
        f = x @ self.W_fx + h @ self.W_fh + self.b_f
        g = x @ self.W_gx + h @ self.W_gh + self.b_g
        o = x @ self.W_ox + h @ self.W_oh + self.b_o
        i, f, g, o = torch.sigmoid(i), torch.sigmoid(f), torch.sigmoid(g), torch.tanh(o)
        _c = f * c + i * g
        _h = o * torch.tanh(_c)
        return _h, _c


class LSTM(nn.Module):
    def __init__(self, n_input, n_hid, n_layers):
        super().__init__()
        self.LSTM_cells = nn.ModuleList([LSTMCell(n_input, n_hid)] + [LSTMCell(n_hid, n_hid)] * (n_layers - 1))
        self.n_hid = n_hid
        self.n_layers = n_layers

    def forward(self, x: torch.Tensor, s=None):
        # s: tuple of (h, c), to adjust ``output, hidden = self.rnn(embeddings)'' in `model.py`
        n_timestamp, n_batch = x.shape[0], x.shape[1]
        if s:
            (h, c) = s
            h, c = list(torch.unbind(h)), list(torch.unbind(c))
        else:
            h = c = [x.new_zeros(n_batch, self.n_hid)] * self.n_layers
        output = []
        for t in range(n_timestamp):
            input = x[t]
            for l in range(self.n_layers):
                h[l], c[l] = self.LSTM_cells[l](input, h[l], c[l])
                input = h[l]
            output.append(h[-1])        # hidden state of the last layer
        output = torch.stack(output)    # hidden state of the last layer of all timestamps
        h = torch.stack(h)              # hidden state of the last timestamp of all layers
        c = torch.stack(c)              # hidden state of the
        return output, (h, c)
