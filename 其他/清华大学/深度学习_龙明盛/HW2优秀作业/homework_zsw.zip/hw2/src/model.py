import torch
import torch.nn as nn
from lstm import LSTM
from mlm import Mask


class RNN(nn.Module):
    # RNN model is composed of three parts: a word embedding layer, a rnn network and an output layer
    # The word embedding layer have input as a sequence of word index (in the vocabulary)
    # and output a sequence of vector where each one is a word embedding
    # The network has input of each word embedding and output a hidden feature corresponding to each word embedding
    # The output layer has input as the hidden feature and output the probability of each word in the vocabulary
    # feel free to change the init arguments if necessary
    def __init__(self, n_voc, n_input, n_hid, n_layers, block_op='GRU'):
        super(RNN, self).__init__()
        self.drop = nn.Dropout(0.5)

        # self.embed change input size BxL into BxLxE
        self.embed = nn.Embedding(n_voc, n_input)
        
        # WRITE CODE HERE within two '#' bar                                              #
        # Construct you RNN model here. You can add additional parameters to the function #
        ###################################################################################
        if block_op == 'LSTM':
            self.rnn = LSTM(n_input, n_hid, n_layers)
        elif block_op == 'GRU':
            self.rnn = nn.GRU(n_input, n_hid, n_layers)
        else:   # 'Bi-GRU'
            self.rnn = nn.GRU(n_input, n_hid // 2, n_layers, bidirectional=True)
        ###################################################################################
        self.decoder = nn.Linear(n_hid, n_voc)
        self.init_weights()
        self.n_hid = n_hid
        self.n_layers = n_layers

    def init_weights(self):
        init_uniform = 0.1
        self.embed.weight.data.uniform_(-init_uniform, init_uniform)
        self.decoder.bias.data.zero_()
        self.decoder.weight.data.uniform_(-init_uniform, init_uniform)
    
    # feel free to change the forward arguments if necessary
    def forward(self, input):
        embeddings = self.drop(self.embed(input))

        # WRITE CODE HERE within two '#' bar                                             #
        # With embeddings, you can get your output here.                                 #
        # Output has the dimension of sequence_length * batch_size * number of classes   #
        ##################################################################################
        output, hidden = self.rnn(embeddings)
        ##################################################################################

        output = self.drop(output)
        decoded = self.decoder(output.view(output.size(0)*output.size(1), output.size(2)))
        return decoded.view(output.size(0), output.size(1), decoded.size(1)), hidden


# WRITE CODE HERE within two '#' bar                                                      #
# your transformer for language modeling implementation here                              #
###########################################################################################
class LMTransformer(nn.Module):
    def __init__(self, n_voc, n_input, n_head, n_hid, n_layers, dropout=0.5, k=0.15, model_op='Transformer'):
        super(LMTransformer, self).__init__()
        self.mask_seq = None
        self.mask_mlm = Mask(n_voc, k, 0.1 * k, 0.1 * k) if 'MLM' in model_op else None
        self.drop = nn.Dropout(dropout)
        self.embed = nn.Embedding(n_voc + ('MLM' in model_op), n_input)     # extra for [mask] token
        self.encoder = nn.TransformerEncoder(nn.TransformerEncoderLayer(n_input, n_head, n_hid, dropout), n_layers)
        self.decoder = nn.Linear(n_input, n_voc)
        self.init_weights()

    def init_weights(self):
        init_uniform = 0.1
        self.embed.weight.data.uniform_(-init_uniform, init_uniform)
        self.decoder.bias.data.zero_()
        self.decoder.weight.data.uniform_(-init_uniform, init_uniform)

    def forward(self, src):
        if self.mask_seq is None or self.mask_seq.shape[0] != src.shape[0]:
            self.mask_seq = self._generate_sequence_mask(src.shape[0], src.device)

        # src = self.drop(self.embed(src)) if self.mask_mlm is None else self.drop(self.embed(self.mask_mlm(src)))
        if self.mask_mlm is not None:
            src = self.mask_mlm(src)
        src = self.drop(self.embed(src))

        output = self.encoder(src, self.mask_seq)
        decoded = self.decoder(output.view(output.size(0)*output.size(1), output.size(2)))
        return decoded.view(output.size(0), output.size(1), decoded.size(1)), None  # to match `output, _ = model(data)`

    @staticmethod
    def _generate_sequence_mask(size, device):
        return torch.triu(torch.full((size, size), float('-inf')), diagonal=1).to(device)
###########################################################################################
