import os
import data
import bertviz
import torch
import torch.nn as nn
from torch import Tensor
from typing import Optional, Tuple
from genericpath import exists


device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
data_loader = data.Corpus("../data/wikitext2", {'train': 20, 'valid': 10}, 35)
model = torch.load('best_model_TransformerLarge.pt').to(device)


def forward_TransformerEncoderLayer(layer: nn.TransformerEncoderLayer,
                                    src: Tensor,
                                    src_mask: Optional[Tensor] = None,
                                    src_key_padding_mask: Optional[Tensor] = None) -> Tuple[Tensor, Tensor]:
    r"""Pass the input through the encoder layer.

    Args:
        src: the sequence to the encoder layer (required).
        src_mask: the mask for the src sequence (optional).
        src_key_padding_mask: the mask for the src keys per batch (optional).

    Shape:
        see the docs in Transformer class.
    """
    x = src
    if layer.norm_first:
        attn_output, attn_output_weights = _sa_block(layer, layer.norm1(x), src_mask, src_key_padding_mask)
        x = x + attn_output
        x = x + _ff_block(layer, layer.norm2(x))
    else:
        attn_output, attn_output_weights = _sa_block(layer, x, src_mask, src_key_padding_mask)
        x = layer.norm1(x + attn_output)
        x = layer.norm2(x + _ff_block(layer, x))
    return x, attn_output_weights


def _sa_block(self: nn.TransformerEncoderLayer, x: Tensor,
              attn_mask: Optional[Tensor], key_padding_mask: Optional[Tensor]) -> Tuple[Tensor, Tensor]:
    (attn_output, attn_output_weights) = self.self_attn(x, x, x,
                                                        attn_mask=attn_mask,
                                                        key_padding_mask=key_padding_mask,
                                                        need_weights=True,
                                                        average_attn_weights=False)
    # attn_output_weights with size (H * S * S)
    return self.dropout1(attn_output), attn_output_weights


def _ff_block(self: nn.TransformerEncoderLayer, x: Tensor) -> Tensor:
    x = self.linear2(self.dropout(self.activation(self.linear1(x))))
    return self.dropout2(x)


def get_attn(sentence: str):
    tokens = data_loader.tokenize_stc(sentence).to(device)
    output, attn_output_weight = model.embed(tokens), None
    layers = model.encoder.layers
    attn_output_weights = []
    # forward of nn.TransformerEncoder (which model.encoder is instance of)
    for layer in layers:
        (output, attn_output_weight) = forward_TransformerEncoderLayer(layer, output)
        # (1 * H * S * S) to adapt to `head_view` of bertviz
        attn_output_weight = attn_output_weight.view(1, attn_output_weight.shape[0], attn_output_weight.shape[1], -1)
        attn_output_weight = attn_output_weight.cpu().detach()
        attn_output_weights.append(attn_output_weight)
        if model.encoder.norm is not None:
            output = model.encoder.norm(output)
    # (|layers| * 1 * H * S * S)
    return attn_output_weights


def view_attn(sentence: str, plot_dir, title):
    if not exists(plot_dir):
        os.makedirs(plot_dir)
    attention = get_attn(sentence)
    token = sentence.split() + ['<eos>']
    html = bertviz.head_view(attention, token, html_action='return')
    with open(os.path.join(plot_dir, title) + '.html', 'w') as file:
        file.write(html.data)


plot_dir = 'plot'
view_attn('I like playing the violin', plot_dir, 'violin')
view_attn('Alice is a girl and she likes playing', plot_dir, 'compound')
