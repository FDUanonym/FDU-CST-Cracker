import argparse
import time
import math
import torch
import torch.nn as nn

import data
from model import *
import util

parser = argparse.ArgumentParser(description='PyTorch Language Model')
parser.add_argument('--epochs', type=int, default=40,
                    help='upper epoch limit')
parser.add_argument('--train_batch_size', type=int, default=20, metavar='N',
                    help='batch size')
parser.add_argument('--eval_batch_size', type=int, default=10, metavar='N',
                    help='eval batch size')
# you can increase the sequence length to see how well the model works when capturing long-term dependencies
parser.add_argument('--max_sql', type=int, default=35, 
                    help='sequence length')
parser.add_argument('--seed', type=int, default=1234,
                    help='set random seed')
# parser.add_argument('--cuda', action='store_true', help='use CUDA device')
# parser.add_argument('--gpu_id', type=int, default=1, help='GPU device id used')

# feel free to add some other arguments
parser.add_argument('--model_op', type=str, default='GRU', help='choose a model to use')
parser.add_argument('--ninput', type=int, default=128, help='embedding dimension')
parser.add_argument('--nhead', type=int, default=2, help='head number')
parser.add_argument('--nhid', type=int, default=128, help='hidden dimension')
parser.add_argument('--nlayers', type=int, default=2, help='layers number')
parser.add_argument('--lr', type=float, default=1.0, help='learning rate')

args = parser.parse_args()

# Set the random seed manually for reproducibility.
torch.manual_seed(args.seed)

# Use gpu or cpu to train
# use_gpu = True

# if use_gpu:
#     torch.cuda.set_device(args.gpu_id)
#     device = torch.device(args.gpu_id)
# else:
#     device = torch.device("cpu")
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

# load data
train_batch_size = args.train_batch_size
eval_batch_size = args.eval_batch_size
batch_size = {'train': train_batch_size, 'valid': eval_batch_size}
data_loader = data.Corpus("../data/wikitext2", batch_size, args.max_sql)


# WRITE CODE HERE within two '#' bar                                                           #
# Build model, optimizer and so on                                                             #
################################################################################################
nvoc = len(data_loader.vocabulary)
if args.model_op == 'GRU' or args.model_op == 'LSTM' or args.model_op == 'Bi-GRU':
    model = RNN(nvoc, args.ninput, args.nhid, args.nlayers, args.model_op).to(device)
elif 'Transformer' in args.model_op:
    model = LMTransformer(nvoc, args.ninput, args.nhead, args.nhid, args.nlayers, model_op=args.model_op).to(device)
else:
    raise AttributeError('--model_op: only [GRU, LSTM, Bi-GRU, Transformer, Transformer+MLM] are supported.')
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.SGD(model.parameters(), lr=args.lr)
scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, factor=0.1)
################################################################################################


# WRITE CODE HERE within two '#' bar                                                           #
# Evaluation Function                                                                          #
# Calculate the average cross-entropy loss between the prediction and the ground truth word    #
# And then exp(average cross-entropy loss) is perplexity                                       #
################################################################################################
def evaluate():
    model.eval()
    data_loader.set_valid()
    total_loss = .0
    iter_num = 0
    while True:
        data, target, end_flag = data_loader.get_batch()
        if end_flag:
            break
        iter_num += 1
        data = data.to(device)
        target = target.to(device)
        output, _ = model(data)
        loss = criterion(output.view(target.shape[0], -1), target)
        total_loss += loss.item()
    return total_loss / iter_num
################################################################################################


# WRITE CODE HERE within two '#' bar                                                           #
# Training Function                                                                            #     
# Calculate the average cross-entropy loss between the prediction and the ground truth word    #
# And then exp(average cross-entropy loss) is perplexity                                       # 
################################################################################################
def train():
    model.train()
    data_loader.set_train()
    total_loss = .0
    iter_num = 0
    while True:
        data, target, end_flag = data_loader.get_batch()
        if end_flag:
            break
        iter_num += 1
        data = data.to(device)
        target = target.to(device)
        optimizer.zero_grad()
        output, _ = model(data)
        loss = criterion(output.view(target.shape[0], -1), target)
        total_loss += loss.item()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 0.5)     # avoid gradient explosion
        optimizer.step()
    return total_loss / iter_num
################################################################################################


# WRITE CODE HERE within two '#' bar                                                           #
# Loop over epochs                                                                             #
################################################################################################
train_loss = [.0] * args.epochs
valid_loss = [.0] * args.epochs
best_loss = float('inf')
for epoch in range(args.epochs):
    print('epoch:{:d}/{:d}'.format(epoch, args.epochs))
    print('*' * 100)
    train_loss[epoch] = train()
    print("training: {:.4f}".format(train_loss[epoch]))
    valid_loss[epoch] = evaluate()
    print("validation: {:.4f}".format(valid_loss[epoch]))
    if valid_loss[epoch] < best_loss:
        best_loss = valid_loss[epoch]
        best_model = model
        torch.save(best_model, 'best_model_{}.pt'.format(args.model_op))
    scheduler.step(train_loss[epoch])
    if optimizer.param_groups[0]['lr'] < 1e-6:
        break

util.plot(train_loss, valid_loss, 'plot', args.model_op)
################################################################################################
